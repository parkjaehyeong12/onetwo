import java.util.Scanner;
public class baek11399 {
    public static void main (String args[]) {
    	Scanner s= new Scanner(System.in);
    	int num = s.nextInt();
    	int sum = 0;
    	int n[] = new int[num];
    	for(int i= 0;i<num;i++) {
    		n[i] = s.nextInt();
    	}
    	for(int i = 0; i<num;i++) {
    		for(int j = 0 ; j<num-1;j++) {
    			if(n[j]>n[j+1]) {
    				int temp = n[j];
    				n[j] = n[j+1];
    				n[j+1]= temp;
    			}
    		}
    	}
    	for(int i = 0; i<num;i++) {
    		sum+=(num-i)*n[i];
    	}
    	System.out.println(sum);
    	
//    	for(int i=0; i<num;i++) {
//    		System.out.print(n[i]+" ");
    	
    	//	System.out.println(sum);
    	
    	}    
    }
