import java.util.Scanner;
public class baek1026 {
   public static void main(String args[]) {
	   Scanner s = new Scanner(System.in);
	   int num = s.nextInt();
	   int a[] = new int[num];
	   int b[] = new int[num];
	   int arank[] = new int[num];
	   int sum=0;
	   for(int i =0;i<num;i++)
		   a[i]=s.nextInt();
	   for(int i =0;i<num;i++)
		   b[i]=s.nextInt();
	   
	   for(int i =0; i<num;i++) {
		   int count=0;
		   for(int j=0;j<num;j++) {
			   if(a[i]>a[j])
				   count++;
		   }
		   arank[i]=count;
	   }
	   //정렬하지 않고 가장 큰 수를 어떻게 찾지
	   for(int i = 0; i<num;i++) {
		   System.out.print(arank[i]+" ");
	   }
	  
	   
   }
}
