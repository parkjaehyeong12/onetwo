import java.util.Scanner;
import java.util.Array;
public class baek1026_1 {
   public static void main(String args[]) {
	   Scanner s = new Scanner(System.in);
	   int num = s.nextInt();
	   int a[] = new int[num];
	   int b[] = new int[num];
	   int sum=0;
	   for(int i =0;i<num;i++)
		   a[i]=s.nextInt();
	   for(int i =0;i<num;i++)
		   b[i]=s.nextInt();
	   
	   Array.a
	   
	   for(int i = 0; i<num; i++) {
		   int amax=a[0];
		   int bmin=b[0];
		   
		   for(int j = 0;j<num;j++) {
			   if(a[j]>amax) {
				   amax=a[j];
			   }
		   }
		   for(int j = 0; j<num;j++) {
			   if(a[j]==amax) {
				   a[j]-=101;
				   break;
			   }
		   }
		   
		   for(int j = 0;j<num;j++) {
			   if(b[j]<bmin) {
				   bmin=b[j];
			   }
		   }
		   
		   for(int j = 0; j<num;j++) {
			   if(b[j]==bmin) {
				   
				   b[j]+=101;
				   break;
			   }
		   }
		   sum+=amax*bmin; 
	   }
	   System.out.println(sum);
   }
}
