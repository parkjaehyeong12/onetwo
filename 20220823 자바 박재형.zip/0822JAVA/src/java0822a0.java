//백준문제풀이 5613
import java.util.Scanner;

public class java0822a0 {
       public static void main (String args[]) {
    	   Scanner s = new Scanner (System.in);
    	   int a = s.nextInt();
    	   int sum = a;
    	   s.nextLine();
    	   
    	   String b = s.next();
    	   int c;
//    	   int sum = a;
    	   
    	   for(;;)
    	   {
    		   c = s.nextInt();
    		  
    		   switch(b)
    		   {
    		   case "+":
    			   a+=c;
    			   break;
    		   case "-":
    			   a-=c;
    			   break;
    		   case "*":
    			   a*=c;
    			   break;
    		   case "/":
    			   a/=c;
    			   break;
    		   case "=":
    			   break;
    		   default :
    		       break;
    		   }
//    		   if(b.equals("+"))
//    			   sum+=c;
//    		   else if(b.equals("-"))
//    			   sum-=c;
//    		   else if(b.equals("*"))
//    			   sum*=c;
//    		   else if(b.equals("/"))
//    			   sum/=c;
//    		   else if(b.equals("="))
//    			   break;

    		   b = s.next(); 
    	   }
    	   System.out.println(sum);
    	   
    	   
    	   
    	   
       }
}
