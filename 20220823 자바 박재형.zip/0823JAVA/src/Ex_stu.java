//부모 클래스로 Person 함수부터 만들기
class Person1{ //-이름과 나이
	private String name;
	private int age;
	
	public String getName() {return this.name;}
	public int getAge() {return this.age;}
	
	public Person1(String n, int a) {
		this.name = n;
		this.age = a;
	}
	
}
//자식 클래스로 Student, Teacher 클래스 만들기

//이중 상속은 지원하지 않은 -> 티쳐는 스튜던트의 자식클래스일 수 없다.

class Student1 extends Person1{//-학교, 이름, 나이
	private String school;
	
	public Student1(String n, int a, String s) {
		super(n,a);
		//super(): 이를 통해서 부모 클래스의 생성자 호출
		this.school = s; //여기에서 이름과 나이가 초기화됨
	}
	public void print() {
		System.out.println("학생 정보");
		System.out.println("이름: "+this.getName());
		System.out.println("나이: "+this.getAge());
		System.out.println("소속: "+this.school);
		//private로 멤버변수가 잠겨있기 때문에
		//public get함수로 정보를 받아온다.
	}
}

class Teacher1 extends Person1{//-소속, 이름, 나이
	private String company;
	
	public Teacher1(String n, int a, String c) {
		super(n,a);
		this.company = c;
	}
	
	public void print() {
		System.out.println("교사 정보");
		System.out.println("이름: "+this.getName());
		System.out.println("나이: "+this.getAge());
		System.out.println("소속: "+this.company);
	}
}

public class Ex_stu {
    public static void main(String args[]) {
    	
    	Student1 stu = new Student1("박재형",26,"KB");
    	//아무런 생성자라도 일단 만들어지는 이상 새로운 객체를 생성할 때 괄호를 비워둘 순 없다.
    	Teacher1 t = new Teacher1("이유나",24,"KB");
    	
    	stu.print();
    	System.out.println();
    	t.print();
    	
    }
	
}
