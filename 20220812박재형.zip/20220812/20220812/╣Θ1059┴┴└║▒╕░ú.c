#include<stdio.h>
int main()
{
	int L;
	scanf_s("%d", &L);
	
	int arr[51];
	
	for (int i = 0; i < L; i++)
		scanf_s("%d ", arr[i]);
	
	int check;
	scanf_s("%d", &check);

	int start = 0;

	for (int i = 0; i < L - 1; i++)
	{
		if (check > arr[i] && check < arr[i + 1])
			break;
		else
			start++;
	}


	int gap;





	return 0;
}