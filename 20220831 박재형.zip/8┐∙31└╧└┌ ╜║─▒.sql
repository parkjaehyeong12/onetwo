-------------------스캇--------------------

--create table customer1(
--cust_id varchar2(20) unique not null,
--cust_code varchar2(10),
--name varchar2(20),
--address varchar2(30)
--);

create table customer(
cust_id varchar2(20) unique not null,
cust_code varchar2(10) primary key,
name varchar2(20),
address varchar2(30)
);

create table wear(
wear_code varchar2(20) primary key,
brand varchar2(20),
type varchar2(20) not null,
name varchar2(20) not null
);

drop table wear;
drop table orders;

create table orders(
orders_num varchar2(20) primary key,
wear_code varchar2(20) not null,
cust_code varchar2(20)  not null,

foreign key(wear_code) references wear(wear_code),
foreign key(cust_code) references customer(cust_code)
);

select *from customer order by cust_code;
select *from wear;
select *from orders;

insert into customer (name, cust_id, cust_code, address) values ('박재형', 'neronim', '100001','대구 북구 복현동');
insert into customer (name, cust_id, cust_code, address) values ('김성환', 'wkdsks', '100002','경북 경산 진량');
insert into customer (name, cust_id, cust_code, address) values ('노민영', 'yellowhair', '100003','대구 동구 신천동 ');
insert into customer (name, cust_id, cust_code, address) values ('도광현', 'education', '100004','대구 달서구 상인동');
insert into customer (name, cust_id, cust_code, address) values ('장혜정', 'afterfglow', '100005','대구 달서구 상인동');

insert into wear (wear_code, brand, type, name) values ('abc123','나이키','바지', '니트 런팬츠');
insert into wear (wear_code, brand, type, name) values ('abc789','아디다스','운동화','W-화이트');
insert into wear (wear_code, brand, type, name) values ('abc258','언더아머','바람막이','후디 재킷');
insert into wear (wear_code, brand, type, name) values ('abc999','필라','가방','백팩');
insert into wear (wear_code, brand, type, name) values ('abc630','노스페이스','패딩','눕시 자켓');

--테이블 wear의 컬럼인 name의 데이터 타입을 20에서 100으로 늘림
--이유는, 바시티 로고 크루넷.... 이름이 너무 길어....
alter table wear modify name varchar2(100);
----------------------------------------------------
insert into wear (wear_code, brand, type, name) values ('abc785','앤더슨벨','스웨터','바시티 로고 크루넷');


commit;
insert into orders (orders_num, wear_code, cust_code) values ('001','abc123','100001');
insert into orders (orders_num, wear_code, cust_code) values ('002','abc630','100004');
insert into orders (orders_num, wear_code, cust_code) values ('003','abc999','100002');
insert into orders (orders_num, wear_code, cust_code) values ('004','abc258','100003');
insert into orders (orders_num, wear_code, cust_code) values ('005','abc789','100005');
insert into orders (orders_num, wear_code, cust_code) values ('006','abc785','100002');

select orders.orders_num 주문번호, wear.name 제품명, customer.name 주문자, address 주소지
from orders join wear on orders.wear_code=wear.wear_code join
customer on customer.cust_code = orders.cust_code order by orders.orders_num;

--realorder 생성
create view realorder as
select orders.orders_num 주문번호, wear.name 제품명, customer.name 주문자, address 주소지
from orders join wear on orders.wear_code=wear.wear_code join
customer on customer.cust_code = orders.cust_code order by orders.orders_num;

select *from realorder;

--realorder2 생성
select orders.orders_num 주문번호, wear.wear_code, customer.name 주문자, address 주문지
from orders join wear on orders.wear_code=wear.wear_code join
customer on customer.cust_code = orders.cust_code order by orders.orders_num;

create view realorder2 as
select orders.orders_num 주문번호, wear.wear_code, customer.name 주문자, address 주문지
from orders join wear on orders.wear_code=wear.wear_code join
customer on customer.cust_code = orders.cust_code order by orders.orders_num;

select *from realorder2;


-------------------스캇1--------------------

create or replace procedure add_wear(
mywear_code varchar2,
mybrand varchar2,
mytype varchar2  ,
myname varchar2
)
is begin
insert into wear values(mywear_code,mybrand,mytype,myname);
end add_wear;



-------------------스캇2--------------------

exec add_wear ('abc133','헌옷','헌옷수거함','거적대기');
exec add_wear ('1','1','1','1');

select * from wear;

delete from wear where brand = '1';


-------------------스캇3--------------------

--박재형 sql 개별과제
--1
create table jieuni(
name varchar2(50) not null,
jieuni_code varchar2(20) primary key,
country varchar2(50)
);


--2
create table kyobobook(
isbn varchar2(20) primary key,
name varchar2(50) not null,
price int not null,
jieuni_code varchar2(20),
foreign key (jieuni_code) references jieuni(jieuni_code)
);

--3
select *from jieuni;
--작가 만들기
insert into jieuni (name, jieuni_code, country) values ('헤르만 헤세', '001', '스위스');
insert into jieuni (name, jieuni_code, country) values ('가와바타 야스나리', '002', '일본');
insert into jieuni (name, jieuni_code, country) values ('알베르 카뮈', '003', '프랑스');
insert into jieuni (name, jieuni_code, country) values ('조지 오웰', '004', '영국');
insert into jieuni (name, jieuni_code, country) values ('황순원', '005', '대한민국');

select *from kyobobook;
--책만들기
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1001', '데미안', 15000, '001');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1002', '싯다르타', 12000, '001');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1003', '설국', 13000, '002');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1004', '고도', 16000, '002');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1005', '명인', 21000, '002');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1006', '이방인', 8000, '003');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1007', '페스트', 15000, '003');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1008', '1984', 6000, '004');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1009', '소나기', 10000, '005');
insert into kyobobook (isbn, name, price, jieuni_code) values ('a1010', '독 짓는 늙은이', 12000, '005');

select jieuni.country 국가, jieuni.name 작가, kyobobook.name 작품명, price 가격
from jieuni join kyobobook
on jieuni.jieuni_code=kyobobook.jieuni_code;

update jieuni set name = '거장 황순원' where name = '황순원';
delete from kyobobook where name = '페스트';


commit;

