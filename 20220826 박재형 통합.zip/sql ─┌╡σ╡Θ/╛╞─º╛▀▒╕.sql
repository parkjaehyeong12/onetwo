--------------------------------------------------------
--  ������ ������ - �����-8��-18-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SAMSUNGLIONS
--------------------------------------------------------

  CREATE TABLE "C##SCOTT"."SAMSUNGLIONS" 
   (	"BATTING" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(20 BYTE), 
	"AGE" NUMBER, 
	"POS" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into C##SCOTT.SAMSUNGLIONS
SET DEFINE OFF;
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('1','������',21,'CF');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('2','������',22,'2B');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('3','���ڿ�',30,'RF');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('4','������',37,'1B');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('5','�Ƿ���',34,'DH');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('6','�̿���',37,'3B');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('7','����ȣ',38,'C');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('8','������',20,'SS');
Insert into C##SCOTT.SAMSUNGLIONS (BATTING,NAME,AGE,POS) values ('9','�輺ǥ',28,'LF');
--------------------------------------------------------
--  DDL for Index SAMSUNGLIONS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##SCOTT"."SAMSUNGLIONS_PK" ON "C##SCOTT"."SAMSUNGLIONS" ("BATTING") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table SAMSUNGLIONS
--------------------------------------------------------

  ALTER TABLE "C##SCOTT"."SAMSUNGLIONS" MODIFY ("BATTING" NOT NULL ENABLE);
  ALTER TABLE "C##SCOTT"."SAMSUNGLIONS" ADD CONSTRAINT "SAMSUNGLIONS_PK" PRIMARY KEY ("BATTING")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  
  --delete
  --�ȿ� ������ ����
  --�� ������� �ְ� �Ϻθ� ���� ���� �ִ�.
  --drop, truncate
  --���̺� ��ü�� ����
  --������ �ȵȴ�.
  --�ʺ������״� �Ⱦ��� �� ������ �˰� �ֱ� �ؾ� �Ѵ�.

