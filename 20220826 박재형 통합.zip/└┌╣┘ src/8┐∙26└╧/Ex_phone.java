abstract class Phone{
    //추상 메소드 선언할 시엔 함수선언만 해두고 자세한 내용 구현X
	abstract public String getNum();
	abstract public String getName();
	abstract public void print();
}
class CellPhone extends Phone{
	private String num;
	private String name;
	public CellPhone(String n, String na) {
		System.out.println("CellPhone 객체가 생성되었습니다.");
		this.num=n;
		this.name=na;
	}
	public String getNum() {return this.num;}
	public String getName() {return this.name;}
	public void print() {
		System.out.println("CellPhone 정보");
		System.out.println("번호: "+this.num);
		System.out.println("휴대폰 이름: "+this.name);
	}
}
//이중 상속(폰->셀폰->스마트폰)
class SmartPhone extends CellPhone{
	private String androidiver;
	private String account;	
	public SmartPhone(String n, String na, String a, String ac) {
		super(n,na);//num, name 초기화     //부모클래스의 생성자에 매개변수가 없다면 굳이 super사용하지 않아도
		this.androidiver=a;               //자동으로 부모클래스 생성자가 실행된다.
		this.account=ac;
		System.out.println("SmartPhone 객체가 생성되었습니다.");
	}
	public void print() {
		System.out.println("SmartPhone 정보");
		System.out.println("번호: "+this.getNum());
		System.out.println("휴대폰 이름: "+this.getName());
		System.out.println("안드로이드 버전: "+this.androidiver);
		System.out.println("계정: "+this.account);
	}	
}
public class Ex_phone {
   public static void main(String args[]) {
	   CellPhone cp = new CellPhone("010-1234-5678","아이스크림폰");
       SmartPhone sp = new SmartPhone("010-4180-4394","갤럭시 노트9","16","neronim");
       System.out.println();
       cp.print(); //CellPhone의 print() 사용
       System.out.println();
       sp.print(); //SmartPhone의 print() 사용
   }
}
