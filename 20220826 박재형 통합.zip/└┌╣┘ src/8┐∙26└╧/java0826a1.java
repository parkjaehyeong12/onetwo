import java.util.Scanner;

abstract class Phone{
  abstract public int getNum();
  abstract public String getName();
  abstract public void print();
}

class CellPhone extends Phone{
	private int num;
	private String name;
	
	public CellPhone(int a, String n) {
		this.num=a;
		this.name=n;
	}
	
	public int getNum() {return this.num;}
	public String getName() {return this.name;};
	
	public void print() {
		System.out.println("번호: "+this.num);
		System.out.println("이름: "+this.name);
	}	
}

class SmartPhone extends CellPhone{
	private int androidver;
	private String account;
	
	public SmartPhone(int a, String n, int and, String ac) {
		super(a,n);
		this.androidver=and;
		this.account=ac;
    }
	
	public void print() {
		System.out.println("번호: "+this.getNum());
		System.out.println("이름: "+this.getName());
		System.out.println("버전: "+this.androidver);
		System.out.println("계정: "+this.account);
	}

}	

public class java0826a1 {
      public static void main (String args[]) {
    	  CellPhone c1 = new CellPhone(6,"투지폰");
    	  c1.print();
    	  System.out.println();
    	  SmartPhone p1 = new SmartPhone(17,"아이폰",9,"neronim1000");
    	  p1.print();
    	     	  
      }
}
