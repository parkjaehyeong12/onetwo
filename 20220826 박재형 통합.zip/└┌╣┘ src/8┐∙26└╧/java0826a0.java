
class A{ //A클래스 선성
	private int n1; //멤버 변수 선언형태
	//실무에선 멤버 변수도 public 으로 사용
	
	public A(int n) {
		System.out.println("n1의 값을 초기화합니다.");
		this.n1=n;
	}
	
	public void setN(int a) {
		this.n1=a;
	}
	public int getN() {return this.n1;}
	public int Sum() {System.out.println("매개변수 없는 Sum실행");return 1;}
	public int Sum(int a, int b) {System.out.println("매개변수 있는 Sum실행");return a+b;}
    //오버로딩:함수명이 같아도 매개변수의 수와 종류가 다르다면 함께 사용가능
}

//상속
class B extends A{
	private int n2; //멤버변수
    
//	public void set() {
//		setN1(1);
//	}
	public B(int a, int b) {
		super(a);
	    this.n2=b;	
	}
	
	public void setN(int a) {
		this.n2=a;
	}
	public int getN() {return this.n2;}
	
}


public class java0826a0 {
  public static void main(String args[]) {
	  A a = new A(1);
	  A aaaa = new A(2);
	  B b = new B(3,4);
	  
	  System.out.println("a의 n1값은 "+a.getN());
	  a.Sum();
	  a.Sum(2, 4);
	  //오버라이딩 적용
	  System.out.println("a 객체의 n1값 "+a.getN());//만약 자식클래스의 메소드가 부모 클래스에도 있다면,
	  System.out.println("b 객체의 n2값 "+b.getN());//자식클래스는 자신의 메소드를 더 우선
	
  }
}
