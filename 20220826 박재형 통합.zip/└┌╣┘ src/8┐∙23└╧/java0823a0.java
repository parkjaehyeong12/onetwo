import java.util.Scanner;
//Person클래스를 부모 클래스로,Student를 자식 클래스로 두기
class Person{ //사람 : 부모클래스, 상위클래스
	//키, 나이
	private String name;
    private String gender;
    
	public Person(String n, String g) {
		this.name=n; this.gender=g;
	}
    
    public void setName(String n) {this.name = n;}
    public String getName() {return this.name;}
    
    public void print_P() {
		System.out.println("사람 정보");
		System.out.println("이름: "+this.name);
		System.out.println("성별: "+this.gender);
	}
}

class Student extends Person{ //학생 : 자식클래스, 하위클래스
	//학번, 학력
	//Person클래스의 멤버를 복붙해 사용
	private int num;
//	private String name;
	
	//멤버 :학번, 학력, 이름 ,키 ,성별
	
	public Student(String n,String g, int num) {  //생성자
		//************************
		//super(): 이 구문을 통해서 부모 클래스의 생성자 호출O
		
		super(n,g);   //부모클래스의 멤버 초기화
		this.num =num; //자식 클래스 자신의 멤버 초기화
		//멤버 3개가 초기화
	}
	
	public void setNum(int n) {this.num = n;}
	public int getNum() {return this.num;}
	
	public void print_S() {
		System.out.println("학생정보");
	    System.out.println("학번: "+this.num);
	}
	
}

public class java0823a0 {
     public static void main(String args[]) {
    	 Scanner s = new Scanner(System.in);
    	 //객체생성
    	 
    	 Person p = new Person("박재형","남자");
    	 //생성자를 일단 하나를 만든다면 아무것도 입력안해
    	 
    	 Student stu = new Student("박재형","남자",16);
    	 
    	 p.setName("박재형"); 
//    	 p.setNum(18130956);    	
    	 
    	 stu.setName("박재형");
    	 //부모클래스의 멤버를 복붙해서 자신의 것으로 만들었기 때문    
    	 
    	 stu.setNum(21611956);
    	 
    	 p.print_P();
    	 
    	 System.out.println();
    	 
    	 stu.print_S();
    	 
    	 Student dd = new Student("휴이","남자",16);
    	 stu.getName();
    	 
     }
}
