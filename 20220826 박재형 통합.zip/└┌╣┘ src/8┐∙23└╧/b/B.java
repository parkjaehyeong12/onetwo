package b; //******************************************
import java.util.Scanner;
import a.*;

public class B extends A {
      public static void main(String args[]) {
    	  //import 통해서 외부 패키지를 포함하면
    	  //외부 클래스에 대한 객체 생성 가능
    	  
//    	  A a= new A();
//    	  a.pub=1; //public 정상 접근 //얘들은 그냥 import를 받아서 사용하는 것
//    	  
////    	  a.pri=2; //private 비정상 접근
////    	  a.pro=3; //protected 비정상 접근
//    	  
    	  
    	  B b = new B(); 
    	  b.pub=1; //얘들은 상속을 받아야 사용이 가능하다.
//    	  b.pri=2;
    	  b.pro=3;
    	  
      }
}
