import java. util.Scanner;

public class change2588 {
   public static void main(String args[]) {
	   Scanner s = new Scanner(System.in);
	   
	   int b= s.nextInt(); //4 7 2 3 8 5

	   int nanu = 10;
	   
	   int c[]= new int[100]; //4 7 2 3 8 5
	   
//	   do {
//        int c = b % nanu;
//		nanu *= 10;
//		while(c>=10)
//		{
//			c/=10;
//		}		
//		System.out.println(c);
//	   }while((double)b/(double)nanu>=0.1  );
	   
	   for(int i = 0; (double)b/(double)nanu>=0.1;i++)
	   {
		    c[i] = (int) (b % nanu);
		    
			nanu *= 10;
			
			while(c[i]>=10)
			{
				c[i]/=10;
			}		
			System.out.println(c[i]);    
	   }
	   

    
	   

	   
   }
}
