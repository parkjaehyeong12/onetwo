import java.util.Scanner;

//상속
class A{
	private int n1;
	
	public A(int a) { //A의 멤버변수 : n1
		this.n1=a;
		System.out.println("클래스 A의 멤버 n1 저장 완료");
		System.out.println("저장된 n1의 값: "+this.n1);
	}
	
	public A(int a, int b) {
	   //오버로딩을 하기 때문에 아무나 생성자 중에 자식클래스 중에 아무거나 하나이상만 들고오면 된다.		
	   this.n1=a;
	}
	
//	public A(int a, String b) { 순서만 바꿔줘도 다른 애로 인식을 한다.
//		
//	}
//	public A(String b ,int a) {
//		
//	}
	
	public void print (String s) {
		System.out.println(s+"의 n1의 값: "+this.n1);		
	}
	
}

class B extends A{ //B의 멤버변수 : n1,n2
    //private int n1가 포함되어 있다.
	private int n2;
	
	public B(int a, int b) {
		super(a); //n1의 값 초기화해서 설정 ->상속해준 클래스의 생성자에 집어넣는다.
		          //생성자 안에선 초기화된다.
		this.n2=b;
		System.out.println("클래스 B의 멤버 n2 저장 완료");
		System.out.println("저장된 n2의 값: "+this.n2);
	
	}
	public B(int a, int b, int c) {
		super(a, b);
	}
	
	public void print (String s) {
		System.out.println(s+"의 n2의 값: "+this.n2);		
	}


}

public class java0824a0 {
        public static void main (String args[]) {
        	Scanner s = new Scanner(System.in);
        	int i = s.nextInt();
        	A a= new A(i); //클래스 A에 대한 객체 생성
        	
        	int j = s.nextInt();
        	int k = s.nextInt();
        	B b = new B(j,k);
        	// 오버라이딩 : 부모 클래스의 함수를 자식 클래스에서 다시 정의
        	// 부모 클래스와 자식 클래스에 동일한 이름의 함수 있어도 정상 작동
        	// 자식 클래스의 객체는 부모 클래스의 함수를 실행하지 X
        	// 결론적으로 자식클래스에선 오버라이딩을 통해 생성자 하나를 덮어쓰기 한다.
        	
        	System.out.println();
        	a.print("a"); //A클래스에 대한 print() 실행
        	b.print("b"); //B클래스에 대한 print() 실행
        	
        	// 자시클래스에서 부모와 함수가 겹칠 시에는 자식인 자신의 함수를 더 우선시해서 실행한다.
        	// A 클래스에 대한 print() 함수는 무시하며 실행X
        	// 부모 클래스의 함수보다 자기 자신의 함수를 우선시
        	
        	
        	
        }
}
