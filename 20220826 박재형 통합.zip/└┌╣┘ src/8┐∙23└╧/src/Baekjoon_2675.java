import java.util.Scanner;

public class Baekjoon_2675 {
   public static void main (String args[]) {
	   Scanner s = new Scanner (System.in);
	   int num = s.nextInt();
	   int check;
	   String arr;
	   
	   //int[] arrtest = new int[10];
	   //System.out.println(arrtest.length);
	   
	   for(int i = 0; i<num;i++) {
		   check = s.nextInt();
		   arr = s.next();
		   char arr1[] = arr.toCharArray();
		   for(int j = 0; j< arr.length() ;  j++)
		   {
			   for(int k = 0;k<check;k++)
				   System.out.print(arr1[j]);
		   }
		   System.out.println();
	   }
  
   }
}
