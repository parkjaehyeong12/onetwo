import java.util.Scanner;

public class Baekjoon_2153 {
    public static void main (String args[]) {
      Scanner s = new Scanner (System.in);	
    	String sentence = s.next();
    	
    }
}
