import java.util.Scanner;
public class Baekjoon_2588 {
  public static void main (String args[]) {
	  Scanner s = new Scanner(System.in);
	  
	  int a = s.nextInt();//472
	  int b = s.nextInt();//3 8 5
	  
	  int b1 = b%10; //1의 자리수
	  int b2 = (b%100-b1)/10; //10의 자리수
	  int b3 = (b-(b%100))/100; //100의 자리수
	  
//	  System.out.println(b1+" "+b2+" "+b3);
	  System.out.println(a*b1);
	  System.out.println(a*b2);
	  System.out.println(a*b3);
	  System.out.println(a*b);
  }
}
