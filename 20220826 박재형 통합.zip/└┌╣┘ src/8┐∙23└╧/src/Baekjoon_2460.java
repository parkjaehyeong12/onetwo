import java.util.Scanner;

public class Baekjoon_2460 {
  public static void main(String args[]) {
	  Scanner s = new Scanner (System.in);
	  int bye = s.nextInt();
	  int get = s.nextInt();
	  int people = get;
	  int max = people;
	  
	  for(int i = 0; i<9; i++) {
		  bye = s.nextInt();
		  get = s.nextInt();
		  people = people + get - bye;
		  if(people>max)
			  max = people;
	  }
	  System.out.println(max);
  }
}
