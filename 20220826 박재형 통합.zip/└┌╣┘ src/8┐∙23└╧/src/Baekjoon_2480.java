import java.util.Scanner;
//2480 주사위문제
public class Baekjoon_2480 {
    public static void main (String args[]) {
    	Scanner s= new Scanner (System.in);
    	int a = s.nextInt();
    	int b = s.nextInt();
    	int c = s.nextInt();
    	int money = 0;
    	
    	if(a == b && b == c)
    		money += 10000 + 1000 * a;
    	else if(a != b && a!=c && b!=c)
    	{
    		if(a>b && a>c)
    			money += 100*a;
    		else if(b>c)
    			money += 100*b;
    		else
    			money += 100*c;
    	}
    	else
    	{
    		if(a==b)
    			money+=1000+100*a;
    		else if(a==c)
    			money+=1000+100*a;
    		else
    			money+=1000+100*b;  		
    	}
    	System.out.println(money);
    	
    	
    	
    }
}
