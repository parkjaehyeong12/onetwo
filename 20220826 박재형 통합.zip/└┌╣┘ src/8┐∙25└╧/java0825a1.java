
abstract class Animal{
	abstract public String getName();
	abstract public String cry(String s);
}

class Cat extends Animal{
	private String name;
	
	public Cat(String n) {
		this.name = n;
	}
	
	public String getName() {return this.name;}	
	public String cry(String s) {return s;}
}

class Dog extends Animal{
	private String name;
	
	public Dog(String n) {
		this.name = n;
	}
	
	public String getName() {return this.name;}
	
	public String cry(String s) {return s;}
}

public class java0825a1 {
       public static void main (String args[]) {
    	   Cat c = new Cat("고양이");
    	   Dog d = new Dog("강아지");
       System.out.println(c.getName()+"의 울음소리는 "+c.cry("야오오옹"));
       System.out.println(d.getName()+"의 울음소리는 "+d.cry("월월월"));
       
       }
}
