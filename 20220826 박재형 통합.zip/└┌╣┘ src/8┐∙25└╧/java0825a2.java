import java.util.Scanner;
//실습 선생님 풀이
abstract class Animal{
	abstract String getName();
	abstract void printcry();
	
}

class Cat extends Animal{
	private String name;
	
	public Cat() {
		this.name="고양이";
	}
	
	public String getName() {
		return this.name;
	}
	
	public void printcry() {
		System.out.println("아오오옹");
	}
	
}

class Dog extends Animal{
	private String name;
	public Dog() {
		this.name="강아지";
	}
	public String getName() {
		return this.name;
	}
	public void printcry() {System.out.println("멍멍멍");}
}



public class java0825a2 {
   public static void main (String args[]) {
	   //고양이와 강아지 객체 생성
	   Cat c = new Cat();
	   Dog d = new Dog();
	   c.printcry();
	   d.printcry();
	   
	   System.out.print(c.getName()+"의 울음 소리는");
	   c.printcry();
	   System.out.print(d.getName()+"의 울음 소리는");
	   d.printcry();
	   
	   
   }
}
