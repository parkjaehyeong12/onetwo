// extends를 이용한 상속을 계속 배워왔음
// 추상 클래스가 이 상속을 더 적극적으로 이용.
// 추상 클래스 :: "추상적인 클래스", 구체적으로 정의되지 않은 클래스
//추상 클래스는 추상 메소드를 하나라도 포함하고 있어야 함,(?)

// 추상 클래스를 통해선 정상적으로 객체를 생성할 수 없음

// 그 말은 즉, 추상 클래스는 반드시 상속받아져서 구체화가 필요함 (상속)
// 추상 메소드: "추상적인 메소드", 구체적으로 정의되지 않은 메소드


abstract class Person{ //추상 클래스로 만든다
	//추상 클래스로 만들기 위해선 abstract 키워드 필요
	//추상 메소드 또한 abstract 키워드 필요

	abstract public void printName();
	abstract public void print();
	
}

class Me extends Person{ //Person 클래스를 구체화하려고 함
	//추상 클래스를 상속받고 난 뒤 빨간줄이 생기는 이유는 추상 메소드를 구체화하지 않았기 때문
	//메소드를 구체화한다는 뜻 = 중괄호를 열어서 명령문을 따로 작성
	
	private String name; //제 자신의 이름 저장
	
	public Me(String n) {
		this.name= n;
	}
	
	public void printName() {
		// 추상 메소드 printName 을 상속받아 구체화하고 있는 과정
		System.out.println("제 이름은 "+this.name+"입니다.");
	}
	public void print() {
		System.out.println("정말 곤란합니다.");
	}
	//추상 메소드 2개를 구체화하고 나면 오류가 없어짐
	
	//"반드시 추상 클래스 안에 있는 추상 메소드에 대한 정의를 해야함"
	
}

public class java0825a0 {
    public static void main(String args[]) {
//    	Person p = new Person();
    	//추상 클래스는 객체 생성 불가능
    	Me m = new Me("박재형");
    	
    	//추상 클래스에 있던 메소드를 정의한 뒤에 사용하는 것
    	
    	//일반 부모클래스의 있는 같은 구성의 메소드들은 오버라이딩이 되었을 텐데, 얘들은 아예 아무것도 없으니까 처음부터
    	//새로 정의해야만 하는 것.
    	
    	m.printName();
    	m.print();
    	
    	
    	
    	
    	
    }
}
