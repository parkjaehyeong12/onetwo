import java.util.*;
//* 은 스캐너도 될 수 있고 뭐든 다 될 수 있다.


//교사 클래스 선언하기
class Teacher{
	//클래스 구성요소 : 필드 (멤버변수), 메소드(멤버 함수), 생성자
	
	//멤버변수 선언부
	private String name;
	private int year;
	private String gender;
	
	// 멤버 함수 선언부
	//this를 통하여 현재 객체를 참조

	public String getName() {return this.name;}
	public int getYear() {return this.year;}
	public String getGen() {return this.gender;}
	public void setName(String n) {this.name= n;}
	public void setYear(int y) {this.year = y;}
	public void setGen(String g) {this.gender=g;}
	
	//생성자 선언부
	//보통 생성자는 객체 생성할 시 자동으로 멤버 변수를 초기화하는 데에 사용
	//1. 클래스 이름과 동일해야 한다.
	//2. 멤버 함수처럼 따로 호출할 수 없는 메소드이다.
	//
	
	//
	//오버로딩: 매개변수의 수와 종류가 다르다면,
	//동일한 이름의 함수라도 함께 사용할 수 있다.
	//보통 오버로딩은 <메소드(멤버함수)와 생성자 선언부>에서 많이 사용
	
	public Teacher(String n, int y, String g ) {
		//생성자를 통해 만들어진 객체의 멤버 변수 초기화
		this.name = n;
		this.year = y;
		this.gender = g;
		
	} //동명이인
	public Teacher (String n, String g) {
		this.name = n;
		this.year = 0;
		this.gender =g;
	}

}

class clock{
	private int hour;
	private int min  ;
	private int sec  ;
	
	
	public int getHour() {return this.hour;}
	public int getMin() {return this.min;}
	public int getSec() {return this.sec;}
	
	public void setHour(int h) {this.hour = h;}
	public void setMin(int m) {this.min = m;}
	public void setSec(int s) {this.sec = s;}
	
	public int gapHour(int a, int b) {return b-a;}
	public int gapMin(int a, int b) {return b-a;}
	public int gapSec(int a, int b) {return b-a;}
	
	public clock(int h, int m, int s) {
		this.hour = h;
		this.min = m;
		this.sec = s;
	}

}



public class java0822 {
      public static void main(String args[]) {
    	  Scanner s = new Scanner(System.in);
    	 
     if(false)
     {
	   //객체 배열 선언
	

      Teacher t[] = new Teacher[3]; //여기서 t는 객체배열
	  
	  //여기까지는 객체생성은 안됐지만, 객체를 생성할 배열 공간이 주어짐.
	  //객체 배열에 대한 객체 생성
	  t[0] = new Teacher("이유나", "여자");//매개변수가 2개인 생성자 호출
	  t[1] = new Teacher("이동준",2,"남자");//매개변수가 3개인 생성자 호출
	  t[2] = new Teacher("박준현",3,"남자");
	  
	  System.out.println("교사목록");
	  for(int i = 0; i<3;i++) {
		  System.out.println("이름: "+t[i].getName());
		  System.out.println("이름: "+t[i].getYear());
		  System.out.println("이름: "+t[i].getGen());
		  System.out.println();
	  }
	  
	  //입력문 포함해서 객체 생성 및 출력하기
	  //자신의 이름, 성별만 입력받은 뒤
	  // 이에 관한 객체를 생성하고 위와 같은 양식으로 출력하기
	  
	 
	  Teacher me = new Teacher(s.next(),s.next());
	  System.out.println("이름: "+me.getName());
	  System.out.println("성별: "+me.getGen());
	  
	  s.nextLine();
	  
	  String name = s.nextLine();
	  String gender = s.nextLine();
	  System.out.println("이름: "+name);
	  System.out.println("성별: "+gender);
	  
	  Teacher tc = new Teacher(s.next(), s.next());
	  //입력값을 바로 생성자의 매개변수로 사용하여 즉시 객체 생성 가능
	  
	  System.out.println("내 정보");
//	  System.out.println(tc.getName()+" "+tc.getYear()+" "+tc.getGen());
	  System.out.println("이름: "+tc.getName());
	  System.out.println("경력: "+tc.getYear());
	  System.out.println("성별: "+tc.getGen());
	  
     }
     
     
	  clock c1 = new clock(s.nextInt(),s.nextInt(),s.nextInt());
	  clock c2 = new clock(s.nextInt(),s.nextInt(),s.nextInt());
	  
//	  int gapHour = c2.getHour()-c1.getHour();
//	  int gapMin = c2.getMin()-c1.getMin();
//	  int gapSec = c2.getSec()-c1.getSec();
	  
	  int a =c2.gapHour(c1.getHour(),c2.getHour());
	  int b =c2.gapMin(c1.getMin(),c2.getMin());
	  int c =c2.gapSec(c1.getSec(),c2.getSec());
	  
	  
	  if(c<0)
	  {
		b -= 1;
		c += 60;
	  }
	  if(b<0)
	  {
		a -=1;
		b += 60;
	  }
	  if(a<0)
		 a+=24;
	  
	  System.out.println("현재 시각은 " +c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
	  System.out.println("점심 시간은 " +c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
	  System.out.println("점심 시간까지 남은 시간은, "+a+"시간 "+b+"분 "+c+"초");
	  
	  
	  
   }
}
