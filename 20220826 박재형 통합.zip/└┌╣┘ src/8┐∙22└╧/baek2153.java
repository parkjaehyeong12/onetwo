//2153
import java. util.Scanner;
public class baek2153 {
   public static void main (String args[]) {
	Scanner s = new Scanner (System.in);
	  
	   String arr = s.next();
	  
	   int sum = 0;
	   int sosucheck = 1;
	   
	   for(int i = 0; i< arr.length();i++)
	   {
		  char alpha =arr.charAt(i);
		  //alpha는 배열 arr의 i번째 문자입니다.
		  
		  if(alpha>=97 && alpha<=122)
			  alpha-=96;
		  else if(alpha>=65 && alpha<=90)
			  alpha -=38;
		  else
			  break;
		  
		  sum += alpha;
	   }
	   for(int i = 2;i<sum;i++)
	   {
		   if( sum%i == 0)
		   {
			   sosucheck = 0;
			   break;
		   }  
	   }

	   if(sosucheck == 1)
		   System.out.println("It is a prime word.");
	   else
		   System.out.println("It is not a prime word.");
	   
   }
}
