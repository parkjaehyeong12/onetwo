import java.util.Scanner;

class Person{
	private String name;
	private int age;
	
	public Person(String n, int a) {
		this.name=n;
		this.age=a;
	}
	public void setName(String n) {this.name=n;}
	public void setAge(int a) {this.age=a;}
	
	public String getName() {return this.name;};
	public int getAge() {return this.age;}
	
}

class Student extends Person{
	private String school;
	
	public Student (String n, int a , String s) {
		super(n,a);
		this.school =s;
	}
	
	public void setSchool(String s) {this.school=s;}
	
	public String getSchool() {return this.school;}
	
	
}

class Teacher extends Person{
	private String party;
	
	public Teacher (String n, int a, String p) {
		super(n,a);
		this.party =p;
	}
	
    public void setParty(String p) {this.party=p;}
	
	public String getParty() {return this.party;}
	
}

public class java0823a1 {
       public static void main(String args[]) {
    	   Scanner s = new Scanner(System.in);
    	   
    	   //next 는 스페이스 즉 공백 전까지 입력받은 문자열을 리턴
    	   //nextLine 은 엔터를 치기 전까지 쓴 문자열을 모두 리턴
    	   
    	   Student me = new Student(s.next(),s.nextInt(),s.next());
    	   System.out.println("이름: "+me.getName());
    	   System.out.println("나이: "+me.getAge());
    	   System.out.println("학교: "+me.getSchool()+"\n");
    	   
    	   Teacher tea = new Teacher("이유나 선생님",24,"경북산업직업전문학교");
    	   System.out.println("이름: "+tea.getName());
    	   System.out.println("나이: "+tea.getAge());
    	   System.out.println("소속: "+tea.getParty());
    	      	   
       }
}
