import java.util.Scanner;

class Point{
	private int x;
	private int y;
	
	public Point(int x, int y) {
		this.x= x;
		this.y= y;
	}
	
	public int getX() {return this.x;}
	public int getY() {return this.y;}
	
	public void setX(int x) {this.x=x;}
	public void setY(int y) {this.y=y;}
	
	
	public void print_XY() {
		System.out.println("여기의 x좌표는 "+x+", y좌표는 "+y+" 입니다.");
	}

	
}

class ColorPoint extends Point{
	private String color;
	
	public ColorPoint(int x, int y, String c) {
		super(x,y);
		
//		System.out.println(this.x+" "+this.y); ->이렇게는 못쓴다.//왜냐하면 private 이니깐
//      //상속은 받았지만 그것을 B 클래스에서 함부로 호출할 수는 없다.
		
		System.out.println(getX()+" "+getY()+"\n");
		
		this.color = c;
	}
	
	public void print_XY() {
		System.out.println("여기의 x좌표는 "+getX()+", y좌표는 "+getY()+", 색상은 "+this.color+" 입니다.");
	}
	
}

public class Ex_point {
     public static void main (String args[]) {
    	 Scanner s = new Scanner(System.in);
    	 int x = s.nextInt();
    	 int y = s.nextInt();
    	 String color = s.next();
    	 
    	 Point p1 = new Point(x,y);
    	 ColorPoint c1 = new ColorPoint(x,y,color);

    	 p1.print_XY();
    	 c1.print_XY();
    	 
     }	
}
