import java.util.Scanner;
class Cal{
	private char plus;
	private char minus;
	private char gob;
	private char nanu;
	private char namuji;
	private int a;
	private int b;
	
	public char getplus() {return this.plus;}
	public char getminus() {return this.minus;}
	public char getgob() {return this.gob;}
	public char getnanu() {return this.nanu;}
	public char getnamuji() {return this.namuji;}
	
	public char getCal() {return this.nanu;}
	
	public Cal(){
		}
	
	
}

public class calculator2 {
	public static void main(String[] args) {
		
		
		

	}

}
