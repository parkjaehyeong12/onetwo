
import java.util.Scanner;
//현재 시각 저장하는 클래스 만들기
class Clock{
	private int hour; //시간
	private int minute; //분
	private int second; //초
	
	//생성자 
	public Clock(int h, int m, int s) {
		this.hour = h;
		this.minute = m;
		this.second = s;
	}
	
	//멤버함수 만들기
	public void setTime(int h, int m, int s) {
		//해당함수가 호출되면 얼마든지 값을 변경 가능
		this.hour = h;
		this.minute = m;
		this.second = s;
	}
	public int getHour() {return this.hour;}
	public int getMin() {return this.minute;}
	public int getSec() {return this.second;}
}

public class Ex_clock {
      public static void main(String args[]) {
    	  Scanner s= new Scanner(System.in);
    	  //clock 클래스에 대한 c1,c2 객체 생성
    	  //생성자 통해서 현재 시각(시분초 모두) 초기화
    	  //c1,c2의 멤버 변수 값 동일하게 설정 ->스캐너로 입력받기
    	  System.out.println("현재 시각을 입력하세요. ");
    	  int hour= s.nextInt();
    	  int minute = s.nextInt();
    	  int second = s.nextInt();
    	  
    	  //입력값으로 멤버변수 초기화하면서 객체 생성
    	  Clock c1 = new Clock(hour,minute,second);
    	  Clock c2 = new Clock(hour,minute,second);
    	  
    	  //c2 객체의 시분초 값을 점심시간으로 변경 ->함수만들기
    	  c2.setTime(16, 40, 30);
    	  
    	  
    	  //멤버함수 통해서 c1, c2간 시간차이 계산
    	  //결과가 마이너스가 아니게끔 연산을 추가
 
    	  
    	  //선생님 풀이
    	  int sub_h = c2.getHour()-c1.getHour();
    	  int sub_s = c2.getSec()-c1.getSec();
    	  int sub_m = c2.getMin()-c1.getMin();
    	  
    	  if(sub_s<0) { //계산한 초의 결과가 마이너스일때
    		  sub_s= 60+sub_s;
    		  sub_m--;
    	  }
    	  if(sub_m<0) { //계산한 분의 결과가 마이너스일때
    		  sub_m = 60 + sub_m;
    		  sub_h--;  
    	  }
    	  if(sub_h<0) {
    		  sub_h = 24+sub_h;
    	  }
    	  
//    	  if(sub_s<0)
//    	  {
//    		  sub_s+=60;
//    		  sub_m-=1;
//    	  }
//    	  
//    	  if(sub_m<0)
//    	  {
//    		  sub_m+=60;
//    		  sub_h-=1;
//    	  }
//    	  
//    	  if(sub_h<0)
//    		  sub_h+=24;
//    	  
    	  //야매로 푸는 것을 인정하자 - 아래는 내 방식
    	  
//    	  if(sub_m<10 && sub_s >=10)
//    	  {  
//    	  //아래 양식처럼 출력
//    	  System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
//    	  System.out.println("강의종료 시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
//    	  System.out.println("강의종료 시간까지 남은 시간은 "+sub_h+"시간 0"+sub_m+"분 "+sub_s+"초");
//     
//    	  }
//    	  else if(sub_m<10 && sub_s<10) 
//          {  
//        	  
//           //아래 양식처럼 출력
//           System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
//           System.out.println("강의종료 시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
//           System.out.println("강의종료 시간까지 남은 시간은 "+sub_h+"시간 0"+sub_m+"분 0"+sub_s+"초");
//         
//          }
//    	  else if(sub_m >=10 && sub_s>=10) 
//          {  
//        	  
//           //아래 양식처럼 출력
//           System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
//           System.out.println("강의종료 시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
//           System.out.println("강의종료 시간까지 남은 시간은 "+sub_h+"시간 "+sub_m+"분 "+sub_s+"초");
//         
//          }
//    	  else
//          {  	  
//           //아래 양식처럼 출력
//           System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
//           System.out.println("강의종료 시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
//           System.out.println("강의종료 시간까지 남은 시간은 "+sub_h+"시간 "+sub_m+"분 0"+sub_s+"초");
//         
//          }
    	  
//    	    System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
//          System.out.println("강의종료 시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
//          System.out.println("강의종료 시간까지 남은 시간은 "+sub_h+"시간 "+sub_m+"분 "+sub_s+"초");
    	  
    	  System.out.println("현재 시각은 "+c1.getHour()+"시 "+c1.getMin()+"분 "+c1.getSec()+"초");
          System.out.println("강의 종료시간은 "+c2.getHour()+"시 "+c2.getMin()+"분 "+c2.getSec()+"초");
          
          System.out.print("종료까지 남은 시간은 "+sub_h+"시 ");
          if(sub_m<10) {
        	  System.out.print(0);
          }
          System.out.print(sub_m+"분");
          if(sub_s<10) {
        	  System.out.print(0);
          }
          System.out.print(sub_s+"초");
    	  
    	  
    	  
      }
}
