import java.util.Scanner;
class Cal {
	private char plus = '+';
	private char minus = '-';
	private char gob = '*';
	private char nanu = '/';
	private char namuji= '%';
	
	public char getplus() {return this.plus;}
	public char getminus() {return this.minus;}
	public char getgob() {return this.gob;}
	public char getnanu() {return this.nanu;}
	public char getnamuji() {return this.namuji;}
	
}


public class calculator {
         public static void main (String args[]) {
        	 Scanner s = new Scanner(System.in);
        	 Cal arr = new Cal();
        	 char abc[] = new char[5];
        	 abc[0] =arr.getplus();
        	 abc[1] =arr.getminus();
        	 abc[2] =arr.getgob();
        	 abc[3] =arr.getnanu();
        	 abc[4] =arr.getnamuji();
        	 int sum = 0;
        	 
        	 for(;;)
        	 {      		 
        	 int a = s.nextInt();
        	 int b = s.nextInt();
        	 char c = s.next().charAt(0);
        	 if(a ==0 && b==0)
        		 break;
        	 for(int j = 0;j<5;j++)
        	 {
        		 if(c==abc[j])
        		 {
        			 switch(c)
        			 {case '+':
        	             sum=a+b;
        	             break;
        			 case '-':
            	         sum=a-b;
            	         break;
        			 case '*':
            	         sum=a*b;
            	         break;
        			 case '/':
            	         sum=a/b;
            	         break;
        			 case '%':
            	         sum=a%b;
            	         break;
        			 }	 
        		 }
        	 }
        	 System.out.println(sum);	 
        	 }
        	 
        	 
         }
}
