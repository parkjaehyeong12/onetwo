import java.util.Scanner;

public class HelloWorld4 {
             public static void main(String args[]){
            	 Scanner s = new Scanner(System.in); //스캔을 할 수 있는 상태
            	 
            	 
            	 
            	 
            	 
            	 
            	 
            	 
            	 
            	 
            	 
            	 
             }
}
