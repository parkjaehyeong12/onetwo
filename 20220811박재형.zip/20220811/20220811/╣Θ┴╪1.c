#include<stdio.h>
int yooncheck(int year)
{
	int yoon = 0;      //�������� �ƴ���
	if (year % 4 == 0)
		yoon = 1;
	if (year % 100 == 0)
		yoon = 0;
	if (year % 400 == 0)
		yoon = 1;

	return yoon; //�����̸� 1, �ƴϸ� 0 ��ȯ
}
int main()
{
#pragma region ���� 11720
//���� 11720
	// 
	// 
	//int n;
	//scanf_s("%d", &n);
	//int count = 0;
	//int sum = 0;
	//char word[100];
	//rewind(stdin);
	//gets(word);

	//
	//while (count < n)
	//{
	//	sum += (word[count] - '0');
	//	count++;
	//}

	//printf("%d", sum);


		//int cnt;
		//char num[100];
		//int sum = 0;

		//scanf_s("%d", &cnt);
		//rewind(stdin);

		//scanf_s("%s", &num);

		//for (int i = 0; i < cnt; i++)
		//{
		//	sum += num[i] - '0';
		//}

		//printf("%d", sum);
#pragma endregion
	//�밡�ٴ� �¸��Ѵ�. 1308
	int totalDay1 = 0;
	int totalDay2 = 0;

	int inputyear;
	int inputmonth;
	int inputday;

	int inputyear2;
	int inputmonth2;
	int inputday2;


	scanf_s("%d %d %d", &inputyear, &inputmonth, &inputday);
	scanf_s("%d %d %d", &inputyear2, &inputmonth2, &inputday2);
	for (int year = 0; year < inputyear ; year++)
	{
		if (yooncheck(year) == 1)
			totalDay1 += 366;
		else
			totalDay1 += 365;
	}
	if(yooncheck(inputyear) == 0)
	{ 
	switch (inputmonth)
	{
	case 1:
		totalDay1 += 0;
		break;
	case 2:
		totalDay1 += 31;
		break;
	case 3:
		totalDay1 += 59;
		break;
	case 4:
		totalDay1 += 90;
		break;
	case 5:
		totalDay1 += 120;
		break;
	case 6:
		totalDay1 += 151;
		break;
	case 7:
		totalDay1 += 181;
		break;
	case 8:
		totalDay1 += 212;
		break;
	case 9:
		totalDay1 += 243;
		break;
	case 10:
		totalDay1 += 273;
		break;
	case 11:
		totalDay1 += 304;
		break;
	case 12:
		totalDay1 += 334;
		break;
	default:
		break;
	}
}
	if (yooncheck(inputyear) == 1)
	{
		switch (inputmonth)
		{
		case 1:
			totalDay1 += 0;
			break;
		case 2:
			totalDay1 += 31;
			break;
		case 3:
			totalDay1 += 59;
			totalDay1 += 1;
			break;
		case 4:
			totalDay1 += 90;
			totalDay1 += 1;
			break;
		case 5:
			totalDay1 += 120;
			totalDay1 += 1;
			break;
		case 6:
			totalDay1 += 151;
			totalDay1 += 1;
			break;
		case 7:
			totalDay1 += 181;
			totalDay1 += 1;
			break;
		case 8:
			totalDay1 += 212;
			totalDay1 += 1;
			break;
		case 9:
			totalDay1 += 243;
			totalDay1 += 1;
			break;
		case 10:
			totalDay1 += 273;
			totalDay1 += 1;
			break;
		case 11:
			totalDay1 += 304;
			totalDay1 += 1;
			break;
		case 12:
			totalDay1 += 334;
			totalDay1 += 1;
			break;
		default:
			break;
		}
	}
	totalDay1 += inputday;
	

	for (int year = 0; year < inputyear2; year++)
	{
		if (yooncheck(year) == 1)
			totalDay2 += 366;
		else
			totalDay2 += 365;
	}

	if (yooncheck(inputyear2) == 0)
	{
		switch (inputmonth2)
		{
		case 1:
			totalDay2 += 0;
			break;
		case 2:
			totalDay2 += 31;
			break;
		case 3:
			totalDay2 += 59;
			break;
		case 4:
			totalDay2 += 90;
			break;
		case 5:
			totalDay2 += 120;
			break;
		case 6:
			totalDay2 += 151;
			break;
		case 7:
			totalDay2 += 181;
			break;
		case 8:
			totalDay2 += 212;
			break;
		case 9:
			totalDay2 += 243;
			break;
		case 10:
			totalDay2 += 273;
			break;
		case 11:
			totalDay2 += 304;
			break;
		case 12:
			totalDay2 += 334;
			break;
		default:
			break;
		}
	}
	if (yooncheck(inputyear2) == 1)
	{
		switch (inputmonth2)
		{
		case 1:
			totalDay2 += 0;
			break;
		case 2:
			totalDay2 += 31;
			break;
		case 3:
			totalDay2 += 59;
			totalDay2 += 1;
			break;
		case 4:
			totalDay2 += 90;
			totalDay2 += 1;
			break;
		case 5:
			totalDay2 += 120;
			totalDay2 += 1;
			break;
		case 6:
			totalDay2 += 151;
			totalDay2 += 1;
			break;
		case 7:
			totalDay2 += 181;
			totalDay2 += 1;
			break;
		case 8:
			totalDay2 += 212;
			totalDay2 += 1;
			break;
		case 9:
			totalDay2 += 243;
			totalDay2 += 1;
			break;
		case 10:
			totalDay2 += 273;
			totalDay2 += 1;
			break;
		case 11:
			totalDay2 += 304;
			totalDay2 += 1;
			break;
		case 12:
			totalDay2 += 334;
			totalDay2 += 1;
			break;
		default:
			break;
		}
	}
	totalDay2 += inputday2;

	if (inputyear > inputyear2)
		printf("gg");
	else if (inputyear == inputyear2 && inputmonth > inputmonth2)
		printf("gg");
	else if (inputyear == inputyear2 && inputmonth == inputmonth2 && inputday >= inputday2)
		printf("gg");
	else if (inputyear2 - inputyear > 1000)
		printf("gg");
	else if (inputyear2 - inputyear == 1000 && inputmonth2 - inputmonth > 0)
		printf("gg");
	else if (inputyear2 - inputyear == 1000 && inputmonth2 - inputmonth == 0 && inputday2 >= inputday)
		printf("gg");
	else
		printf("D-%d", totalDay2 - totalDay1);

	return 0;
}