#include<stdio.h>
int main()
{
	printf("�Է��Ͻÿ�\n");
	char a[2048];
	int c;
	scanf_s("%d", &c);
	int sum = 0;
	for (int j = 0; a[j]!=0; j++)
	{
		scanf_s("%c ",&a);
		a[j] = a[j] + '0';
		for (int i = 0; a[i] != NULL; i++)
		{
			a[i] = a[i] + '0';
			sum += a[i];
		}
		if (j = 10)
			break;
	}
	printf("���� %d�̴�.", sum);;
	return 0;
}