#include<stdio.h>
#include"total.h"
int main()
{
	int time;
	printf("�ð�(��) �Է� ");
	scanf_s("%d", &time);
	two(time);
}