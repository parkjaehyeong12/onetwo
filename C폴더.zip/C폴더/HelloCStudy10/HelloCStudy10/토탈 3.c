#include<stdio.h>
#include<Windows.h>
void three()
{
	system("color a0");
	printf("�����մϴ�.");
}
int main()
{
	three();
	return 0;
}