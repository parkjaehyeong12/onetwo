#pragma once
#include<stdio.h>

//1��

int one(int a, int b, int c)
{
	int sum = 0;
	for (int i = a; i <= b; i++)
	{
		if (i % c == 0)
			continue;
		else
		{
			sum += i;
		}
	}
	printf("a���� b���� c�� ����� ������ ���� %d�̴�.", sum);
}

//2��
int two(int sec)
{
	int h, m;
	if (sec >= 3600 || sec < 0)
	{
		printf("�����Դϴ�.");
	}
	else
	{
		h = sec / 60;
		m = sec % 60;
	}
	printf("�ð��� %d�� %d���Դϴ�.", h, m);
	return m;
}

//5��
int five(int num2)
{
	if (num2 < 1)
	{
		printf("���� �ȵȴ�.");
	}
	else
	{
		int sum = 0;
		for (int i = 1; i <= num2; i++)
		{
			sum += i;
		}

		printf("1");
		int a = 1;
		while (a != num2)
		{
			a++;
			printf("+%d", a);
		}
		printf("=%d", sum);
		return sum;
	}
}

//6��
int six(int a, int b)
{
	int sum = a;
	for (int i = a; i <= b; i++)
	{
		sum *= i;
	}
	printf("%d", a);
	while (a != b)
	{
		a++;
		printf("*%d", a);
	}
	printf("=%d", sum);
	return sum;
}

//7��
int seven(int a, int b, char c)
{
	if (c == '+')
	{
		int sum = 0;
		for (int i = a; i <= b; i++)
		{
			sum += i;
		}
		printf("%d", a);
		while (a != b)
		{
			a++;
			printf("+%d", a);
		}
		printf("=%d", sum);
		return sum;
	}
	else if (c == '*' || c == 'x')
	{
		int sum = a;
		for (int i = a; i <= b; i++)
		{
			sum *= i;
		}
		printf("%d", a);
		while (a != b)
		{
			a++;
			printf("*%d", a);
		}
		printf("=%d", sum);
		return sum;
	}
	else
	{
		printf("���ܻ�Ȳ�Դϴ�.");
		return 0;
	}
}

//8��
int eight(int n)
{
	int i = 1;
	int sum = 1;
	while (i < n)
	{
		i++;
		sum *= i;
	}
	printf("���� %d�Դϴ�.", sum);
}

//9��
int i = 1;
int nine();
int nine(int a)
{
	int sum0 = 1;

	while (i <= a)
	{
		i++;
		sum0 *= i;
		if (i == a)
		{
			printf("���� %d�Դϴ�.", sum0);
			break;
		}
	}
	nine(a);
}

//10��
int ten(int ww)
{
	int t0 = 0, t1 = 1, next = 0;
	printf("�Ǻ���ġ ����: %d ", t1);
	next = t0 + t1;

	int j = 2;
	while (j <= ww)
	{
		printf("%d ", next);
		t0 = t1;
		t1 = next;
		next = t0 + t1;
		j++;
	}
	return 0;
}