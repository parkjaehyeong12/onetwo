#pragma once
int eight(int n)
{
	int i = 1;
	int sum = 1;
	while (i<n)
	{
		i++;
		sum *= i;
	}
	printf("���� %d�Դϴ�.",sum);
}