#pragma once
int five(int num2)
{
	if (num2 < 1)
	{
		printf("���� �ȵȴ�.");
	}
	else
	{
		int sum = 0;
		for (int i = 1; i <= num2; i++)
		{
			sum += i;
		}

		printf("1");
		int a = 1;
		while (a != num2)
		{
			a++;
			printf("+%d", a);
		}
		printf("=%d", sum);
		return sum;
	}
}