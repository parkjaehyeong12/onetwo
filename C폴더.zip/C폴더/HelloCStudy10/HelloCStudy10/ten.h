#pragma once
int ten(int ww)
{
    int t0 = 0, t1 = 1, next = 0;
    printf("�Ǻ���ġ ����: %d ", t1);
    next = t0 + t1;

    int j = 2;
    while (j <= ww)
    {
        printf("%d ", next);
        t0 = t1;
        t1 = next;
        next = t0 + t1;
        j++;
    }
    return 0;
}