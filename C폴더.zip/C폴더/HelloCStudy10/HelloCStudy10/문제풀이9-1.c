#include<stdio.h>
#include"total.h"
int main()
{
	int n;
	printf("����� ��? ");
	scanf_s("%d", &n);
	nine(n);
	printf("\n");
	return 0;
}
