#pragma once
int i = 1;
int nine();
int nine(int a)
{
	int sum0 = 1;

	while (i <= a)
	{
		i++;
		sum0 *= i;
		if (i == a)
		{
			printf("���� %d�Դϴ�.", sum0);
			break;
		}
	}
	nine(a);
}