#include<stdio.h>
#include<Windows.h>

void color(char c, char d)
{
	char abc[10] = "color ";
	abc[6] = c;
	abc[7] = d;
	//char a;
	//char b;
	//rewind(stdin);
	//scanf_s("%c", &abc[6], 1);
	//rewind(stdin);
	//scanf_s("%c", &abc[7], 1);
	abc[8] = NULL;
	system(abc);
}


int main()
{
	char a, b;
	printf("����?");
	scanf_s("%c", &a,1 );
	rewind(stdin);
	scanf_s("%c",  &b,1);
	color(a, b);
	printf("test\n");
}