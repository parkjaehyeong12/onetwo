#pragma once
int seven(int a, int b, char c)
{
	if (c == '+')
	{
		int sum = 0;
		for (int i = a; i <= b; i++)
		{
			sum += i;
		}
		printf("%d", a);
		while (a != b)
		{
			a++;
			printf("+%d", a);
		}
		printf("=%d", sum);
	}
	else if (c == '*' || c == 'x')
	{
		int sum = a;
		for (int i = a; i <= b; i++)
		{
			sum *= i;
		}
		printf("%d", a);
		while (a != b)
		{
			a++;
			printf("*%d", a);
		}
		printf("=%d", sum);
	}
	else
	{
		printf("���ܻ�Ȳ�Դϴ�.");
		return 0;
	}
}
