#pragma once
int six(int a, int b)
{
	int sum = a;
	for (int i = a; i <= b; i++)
	{
		sum *= i;
	}
	printf("%d", a);
	while (a != b)
	{
		a++;
		printf("*%d", a);
	}
	printf("=%d", sum);
	return sum;
}