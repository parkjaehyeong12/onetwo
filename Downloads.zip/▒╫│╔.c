#include<stdio.h>
int main()
{
	if (0)
	{
	double a = 100;
	printf("%7lf�� a��", a);
	system("color a1");
	return 0;
	}
}