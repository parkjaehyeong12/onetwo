import java.util.Scanner;

public class HW {
      public static void main(String args[]) {
    	  Scanner s = new Scanner(System.in);
    	  
    	  //1번
    	
    	  String str = s.nextLine();
    	  int count=0;
    	  int alphabet[] =new int[26];
    	  
    	  
    	  
    	  
      }
}
