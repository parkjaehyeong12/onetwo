#include<stdio.h>
int main()
{//11718
	char arr1[100];
	char arr2[100];
    char arr3[100];

	gets(arr1);
	rewind(stdin);

	gets(arr2);
	rewind(stdin);

	gets(arr3);

	for (int i = 0; arr1[i] != NULL; i++)
		printf("%c", arr1[i]);
	printf("\n");

	for (int i = 0; arr2[i] != NULL; i++)
		printf("%c", arr2[i]);
	printf("\n");
	for (int i = 0; arr3[i] != NULL; i++)
		printf("%c", arr3[i]);


	return 0;
}