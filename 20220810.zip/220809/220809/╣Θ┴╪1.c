#include<stdio.h>//3003
int main()
{
	int chess[6] = { 1,1,2,2,2,8 };
	int myCount[6];
	int gap[6];

	scanf_s("%d %d %d %d %d %d", &myCount[0], &myCount[1], &myCount[2], &myCount[3], &myCount[4], &myCount[5]);
	for (int j = 0; j < 6; j++)
	{
		printf("%d ",chess[j] - myCount[j]);
	}

	//10809
	char arr[100];
	gets(arr);

	int count[26];
	for (int i = 0; i < 26; i++)
		count[i]=0;

	for (int j = 0; j < 26; j++)
	{
		for (int k = 0; arr[k] != NULL; k++)
		{
			if (arr[k] == 97 + j)
				break;
			else
				count[j]++;
		}
	}
	int arrcount = 0;
	for (int k = 0; arr[k] != NULL; k++)
		arrcount++;

	for (int i = 0; i < 26; i++)
	{
		if (count[i] == arrcount)
			count[i] = -1;
	}



	for (int i = 0; i < 26; i++)
		printf("%d ",count[i]);



	return 0;
}