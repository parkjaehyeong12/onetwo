#include<stdio.h>  //3040
int main()
{
	int boy[9];
	int check;
	int sum = 0;
	int a;
	int b;

	for (int i = 0; i < 9; i++)
		scanf_s("%d", &boy[i]);

	for (int i = 0; i < 9; i++)
		sum += boy[i];
	check = sum - 100;

	for (int i = 0; i < 9; i++)
	{
		for (int j = i+1; j < 9; j++)
		{
			if (boy[i] + boy[j] == check)
			{
				a = boy[i];
				b = boy[j];
			}
		}
	}
	for (int i = 0; i < 9; i++)
	{
		if (boy[i] == a || boy[i] == b)
			continue;
		else
			printf("%d\n", boy[i]);
	}
	return 0;
}